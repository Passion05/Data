from itertools import chain, combinations

def load_dataset():
    # Sample dataset
    return [
        ['milk','bread','eggs'],
        ['milk','bread'],
        ['milk','butter'],
        ['bread','butter'],
        ['bread','eggs'],
        ['butter']
    ]

def generate_candidates(itemset, k):
    return list(combinations(set(itemset), k))

def support_count(dataset, candidate):
    count = 0
    for transaction in dataset:
        if set(candidate).issubset(set(transaction)):
            count += 1
    return count

def apriori(dataset, min_support):
    itemset = list(set(chain(*dataset)))
    frequent_itemsets = []
    k = 1
    while itemset:
        candidates = generate_candidates(itemset, k)
        frequent_candidates = []
        for candidate in candidates:
            support = support_count(dataset, candidate) / len(dataset)
            if support >= min_support:
                frequent_itemsets.append(candidate)
                frequent_candidates.append(candidate)
        itemset = list(set(chain(*frequent_candidates)))
        k += 1
    return frequent_itemsets

if __name__ == "__main__":
    dataset = load_dataset()
    min_support = 0.5
    frequent_itemsets = apriori(dataset, min_support)
    print("Frequent Itemsets:")
    for itemset in frequent_itemsets:
        print(itemset)
